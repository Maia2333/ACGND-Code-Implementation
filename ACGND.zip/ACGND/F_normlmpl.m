clear
clc

% x0 = [0.600560937777600;-0.716227322745569;-0.156477434747450;0.831471050378134];
% x0 = rand(100,1);

c = 50;
% c = 5;


gamma = 50;
% gamma = 5;

epsilon = 1;

k = 1;

F_norm(x0,c,gamma,epsilon,k);