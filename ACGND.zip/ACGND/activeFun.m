function [output] = activeFun(E)
%ACTIVEFUN 

% Power-sigmoid activation function:
 xi=4; p=3; 
output=(1+exp(-xi))/(1-exp(-xi))*(1-exp(-xi*E))./(1+exp(-xi*E));
i=find(abs(E)>=1);
output(i)=E(i).^p;

% Hyperbolic_sine activation function:
% output = (exp(2*E)-exp(-2*E))/2;

% *Power function:
% a = 1;
% alpha = 3;
% fi = a*(fi.^alpha);
% output = fi;

%Odd power activation function:
% p = 5;
% fi = fi.^p;

% Hyperbolic sine activation function:
% p = 5;
% for i =1:4
%     for j = 1:4
%         fi(i,j) = exp(p*fi(i,j))/2 - exp(-p*fi(i,j))/2;
%     end
% end 

% % *Linear function:
% a = 1;
% output = a*E;

% *Bipolar-sigmoid function:
% zeta = 4;
% fi = 1+exp(-zeta)/1-exp(-zeta) * 1-exp(-zeta*fi)/1+exp(-zeta*fi);

% *Power-sigmoid function:
% a = 1;
% alpha = 3;
% zeta = 4;
% if abs(fi)>=1
%     fi = a*(fi^alpha);
% else 
%     fi = 1+exp(-zeta)/1-exp(-zeta) * 1-exp(-zeta*fi)/1+exp(-zeta*fi);
% end

% *S-B-P function:
% p = 0.2;
% a = 1;
% if fi>0
%     sign_1p = abs(fi)^1/p;
% elseif fi == 0
%     sign_1p = 0;
% elseif fi<0
%     sign_1p = -abs(fi)^(1/p);
% end
% fi = a*(sign(x)^p+sign_1p);


% output = fi;
end

