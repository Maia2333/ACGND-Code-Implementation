function [output] = diffM(t)
%DIFFM 
syms a;
M(a) = MatrixM(a);
dotM(a) = diff(M,a);
M = dotM(t);
output = (M);

end

