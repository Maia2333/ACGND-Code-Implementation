function [output] = OZNN(t,x,gamma,c)
%OZNN 

A = MatrixA(t);
% M = MatrixM(t);
I = eye(size(A));

dotA = diffA(t);

err=A * reshape(x,10,10) - I;

dotX = pinv(A) * (-dotA * reshape(x,10,10) - gamma * (err));
% dotX = pinv(A) * (-dotA * reshape(x,2,2) - gamma * (err));
output  = dotX(:);

t

end

