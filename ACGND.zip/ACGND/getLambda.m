function [output] = getLambda(err)
%GETLAMBDA 
alpha = 0.1; %����tau
% beta = 1;  %����lambda
beta = 10;
nerr = norm(err);
Lambda = 0.5*(beta+nerr)/alpha;
output = Lambda;
end

