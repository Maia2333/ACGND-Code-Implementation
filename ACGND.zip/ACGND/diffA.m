function [output] = diffA(t)
syms a;
A(a) = MatrixA(a);
dotA(a) = diff(A,a);
A = dotA(t);
output = double(A);

% output = [cos(t), -sin(t);
% sin(t),  cos(t)];

% output = [     5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4,       -sin(5*t), -(5*sin(5*t))/6, -(5*sin(5*t))/7, -(5*sin(5*t))/8, -(5*sin(5*t))/9;
%     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4,       -sin(5*t), -(5*sin(5*t))/6, -(5*sin(5*t))/7, -(5*sin(5*t))/8;
% -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4,       -sin(5*t), -(5*sin(5*t))/6, -(5*sin(5*t))/7;
% -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4,       -sin(5*t), -(5*sin(5*t))/6;
% -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4,       -sin(5*t);
%       -sin(5*t), -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3, -(5*sin(5*t))/4;
% -(5*sin(5*t))/6,       -sin(5*t), -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2, -(5*sin(5*t))/3;
% -(5*sin(5*t))/7, -(5*sin(5*t))/6,       -sin(5*t), -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t), -(5*sin(5*t))/2;
% -(5*sin(5*t))/8, -(5*sin(5*t))/7, -(5*sin(5*t))/6,       -sin(5*t), -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t),     -5*sin(5*t);
% -(5*sin(5*t))/9, -(5*sin(5*t))/8, -(5*sin(5*t))/7, -(5*sin(5*t))/6,       -sin(5*t), -(5*sin(5*t))/4, -(5*sin(5*t))/3, -(5*sin(5*t))/2,     -5*sin(5*t),      5*cos(5*t)];
 
end

