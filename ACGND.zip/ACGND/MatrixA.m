function [output] = MatrixA(t)
% low-order
% A = [sin(t),cos(t);
%     -cos(t),sin(t);];

% high-order
for i =1:10
    for j = 1:10
        if(i==j)
            A(i,j)=10+sin(5*t);
        elseif(i>j)
            A(i,j)=cos(5*t)/(i-j);
        else
            A(i,j)=cos(5*t)/(j-i);
        end
    end
end


% A = [exp(t),exp(-t);
%     -exp(-t),exp(t);];

output = A;
end

