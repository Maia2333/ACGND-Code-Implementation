function [output] = getG(E,x,t)
% x_real = [sin(t),-cos(t);cos(t),sin(t)];
x = reshape(x,10,10);
x_real = MatrixA(t);
RelTol = norm(x - x_real);
AbsTol = RelTol/norm(x);

if E>max(RelTol, AbsTol)
    G = x;
else
    G = 0;
end

output = G;
end

