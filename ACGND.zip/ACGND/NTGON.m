function [output] = NTGON(t,x,gamma,k)
%NTGON 
A =  MatrixA(t);
M = MatrixM(t);
I = eye(size(A));

M4 = kron(eye(size(A)),A');

err = M*x - vecMatrix(I);
dotErr = diffErr(t,x,I);

% dotX = -gamma*(M4)*activeFun(err);
dotX = -gamma*(M4)*(err)-k*M4*dotErr;
output  = dotX;

t
end

