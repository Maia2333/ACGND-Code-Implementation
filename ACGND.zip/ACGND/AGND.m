function [output] = AGND(t,x,gamma,c)
%AGND

dotA = diffA(t);

A =  MatrixA(t);
% M = MatrixM(t);

I = eye(size(A));
% [m,n] = size(I);
diffM = kron(eye(size(A)),dotA);
% diffm = diffM(t);
M4 = kron(eye(size(A)),A');
M5 = kron(eye(size(A)),A);

err = M5*x - vecMatrix(I);
% X = reshape(x,m,n);

Xi = (c*abs(err'*vecMatrix(diffM*x)))/norm(abs(M5*err))^2;
output=-Xi*M4*(err);


% t

end

