function [output] = OGNN(t,x,gamma,c)
%OGNN 
A =  MatrixA(t);
% M = MatrixM(t);
I = eye(size(A));

M4 = kron(eye(size(A)),A');
M5 = kron(eye(size(A)),A);

err = M5*x - vecMatrix(I);


% dotX = -gamma*(M4)*activeFun(err);
dotX = -gamma*(M4)*(err);
output  = dotX(:);

% t
end

