function [output] = ACGND(t,x,gamma,c)
%AGND

% dotA = diffA(t);
A =  MatrixA(t);

M = MatrixM(t);
I = eye(size(A));

% M4 = kron(eye(size(A)),A');
% M5 = kron(eye(size(A)),A);

err = A*reshape(x,10,10) - (I);

Gamma = getLambda(err);
% output=-Gamma*M4*activeFun(err);


t
end

