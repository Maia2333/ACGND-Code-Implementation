function [] = F_norm(x0,c,gamma,epsilon,k)
tspan = [0,1];

ODE = ODE_Solvers;
options = odeset();
% tau = 1/25000;
tau = 1/10000;

% CNRI
% [t,x] = ode45(@CNRI,tspan,x0,options);
% tic
% [t,x] = ODE.RK4(@CNRI,tspan,tau,x0,gamma,c);
% toc
% OZNN
% [t,x] = ode45(@OZNN,tspan,x0,options,gamma);
% tic
% [t,x] = ODE.RK4(@OZNN,tspan,tau,x0,gamma,c);
% toc
% DPZNN
% [t,x] = ode45(@DPZNN,tspan,x0,options,gamma,epsilon);
% tic
% [t,x] = ODE.RK4(@DPZNN,tspan,tau,x0,gamma,epsilon);
% toc
% OGNN
% [t,x] = ode45(@OGNN,tspan,x0,options,gamma);
% tic
% [t,x] = ODE.RK4(@OGNN,tspan,tau,x0,gamma,c);
% toc
% NTGON
% [t,x] = ode45(@NTGON,tspan,x0,options,gamma,k);
% ACGND
% [t,x] = ode45(@AGND,tspan,x0,options,gamma,c);
% tic
% [t,x] = ODE.RK4(@AGND,tspan,tau,x0,gamma,c);
% toc
% AGND
% [t,x] = ode45(@ACGND,tspan,x0,options,c);
% tic
% [t,x] = ODE.RK4(@ACGND,tspan,tau,x0,gamma,c);
% toc

nerr = zeros(length(t),1);
x_real = zeros(size(x));
for i = 1:length(t)
    T = t(i);
    X = x(i,:);
    C = eye(10,10);
%     C = eye(2,2);
    [m,n] = size(C);
    vecC = reshape(C,m*n,1);
    M = MatrixM(T);
    A = MatrixA(T);
    err = M*(x(i,:))' - vecC;  
%     err = reshape(A * reshape(X,m,n) - C,m*n,1); 
    nerr(i) = norm(err);
    X_real = reshape(A',m*n,1);
    x_real(i,:) = X_real(:);
end


% 绘制x x_real图像
figure(2)
subplot(2,2,1)
plot(t,x(:,1),'LineWidth',2.5,'Color','#25CCF7');hold on     %计算值
plot(t,x_real(:,1),'LineWidth',2.5,'linestyle','--','Color','#EA2027')   %真实值
text(0.2,0.8,'$X_{11}$','Interpreter','latex','FontSize',15)
text(1.5,0.1,'$t(s)$','Interpreter','latex','FontSize',20)

subplot(2,2,2)
plot(t,x(:,2),'LineWidth',2.5,'Color','#25CCF7');hold on     %计算值
plot(t,x_real(:,2),'LineWidth',2.5,'linestyle','--','Color','#EA2027')   %真实值
text(0.2,0.6,'$X_{12}$','Interpreter','latex','FontSize',15)
text(1.5,-0.85,'$t(s)$','Interpreter','latex','FontSize',20)

subplot(2,2,3)
plot(t,x(:,3),'LineWidth',2.5,'Color','#25CCF7');hold on     %计算值
plot(t,x_real(:,3),'LineWidth',2.5,'linestyle','--','Color','#EA2027')   %真实值
text(0.2,0,'$X_{21}$','Interpreter','latex','FontSize',15)
text(1.5,-1,'$t(s)$','Interpreter','latex','FontSize',20)

subplot(2,2,4)
plot(t,x(:,4),'LineWidth',2.5,'Color','#25CCF7');hold on    %计算值
plot(t,x_real(:,4),'LineWidth',2.5,'linestyle','--','Color','#EA2027')   %真实值
text(0.2,0.8,'$X_{22}$','Interpreter','latex','FontSize',15)
text(1.5,0.1,'$t(s)$','Interpreter','latex','FontSize',20)

% 绘制误差图像
figure(3);
% plot(t,nerr(:),'LineWidth',2,'linestyle',':','Color','#F97F51')      %OZNN
% plot(t,nerr(:),'LineWidth',1.5,'linestyle','-.','Color','#58B19F')      %DPZNN
% plot(t,nerr(:),'LineWidth',1.5,'linestyle',':','Color','#6D214F')      %OGNN
% plot(t,nerr(:),'LineWidth',1.5,'linestyle','--','Color','#FC427B')     %NTGON
% plot(t,nerr(:),'LineWidth',2,'linestyle','-','Color','#25CCF7')     %AGND qs
plot(t,nerr(:),'LineWidth',2,'linestyle','--','Color','#EA2027')     %AGND hs
hold on
text(2.5,0.1,'$t(s)$','Interpreter','latex','FontSize',20)
text(0.1,2.5,'${\left\| {\epsilon(t)} \right\|_{\rm{F}}}$','Interpreter','latex','FontSize',20)
% text(0.3,1.6,'$\phi_{hs}$','Interpreter','latex','FontSize',20)
% text(0.5,1.1,'$\phi_{ps}$','Interpreter','latex','FontSize',20)
hold on;


x = 0:0.01*pi:2*pi; % Generate x-coordinates
y = x; % Calculate y-coordinates
plot(x,y); % Plot the function
axis off;

end

