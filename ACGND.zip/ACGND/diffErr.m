function [output] = diffErr(t,x,I)
syms a;
M(a) = MatrixM(a);
Err(a) = M*x-vecMatrix(I);
dotErr(a) = diff(Err,a);
dotErr = dotErr(t);
output = double(dotErr);
end

