function [output] = vecMatrix(input)
%VECMATRIX
output = input(:);
end

