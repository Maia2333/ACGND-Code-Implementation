function [output] = CNRI(t,x,gamma,c)
%CNRI 
A =  MatrixA(t);

M4 = kron(eye(size(A)),A');
M5 = kron(A',eye(size(A)));

P_k = M4+M5;
I = eye(size(A));
b_k = vecMatrix(I);

x_k1 = x-P_k'*(P_k*x-b_k);

output = x_k1;
% t
end

