function [output] = DPZNN(t,x,gamma,epsilon)
%DPZNN
A = MatrixA(t);
I = eye(size(A));

dotA = diffA(t);
err=A * reshape(x,10,10) - I;
Gamma = gamma*exp(norm(err)+epsilon*t*getG(norm(err),x,t));
    

% dotX = pinv(A) * (-dotA * reshape(x,2,2) - Gamma * activeFun(err));
dotX = pinv(A) * (-dotA * reshape(x,10,10) - Gamma * (err));
output  = dotX(:);

t
end

