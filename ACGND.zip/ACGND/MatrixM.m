function [output] = MatrixM(t)
A = MatrixA(t);
B = eye(size(A));
output = kron(B,A);
end

