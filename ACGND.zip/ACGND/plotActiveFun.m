clear
clc
% 定义要绘制的函数
% f = @(x) (exp(2*x)-exp(-2*x))/2;

% f = @(x) x;

f = @(x)(x.^3);

xi=4; p=3;
for j=1:1000
    if (abs(x(j))>=1)
        y(:,j)=x(j).^p;
    else
        y(:,j)=((1+exp(-xi))/(1-exp(-xi)))*((1-exp(-xi*x(j)))./(1+exp(-xi*x(j))));
    end
end

% 生成x坐标
x = linspace(-2*pi, 2*pi, 1000);

% 计算y坐标
y = f(x);

% 绘制函数
plot(x, y);
% plot(x, y,'LineWidth',2,'linestyle','-','Color','#25CCF7')     %AGND qs
plot(x, y,'LineWidth',2,'linestyle','-','Color','#25ACF7')
plot(x, y,'LineWidth',2,'linestyle','-','Color','#25ASF7')
hold on;

% 关闭默认坐标轴
axis off;

% 获取坐标轴限制
xl = xlim;
yl = ylim;

% 绘制x轴
plot(xl, [0 0], 'k');

% 绘制y轴
plot([0 0], yl, 'k');

% 在坐标轴上添加箭头
quiver(xl(2), 0, 10, 0, 'k', 'MaxHeadSize', 4);
quiver(0, yl(2), 0, 10, 'k', 'MaxHeadSize', 4);

% 在坐标轴上添加刻度线
xticks(-2*pi:pi:2*pi);
yticks(-20:10:20);

% 在刻度线上添加标签
xticklabels({'-2\pi', '-\pi', '0', '\pi', '2\pi'});
yticklabels({'-20', '-10', '0', '10', '20'});

% 打开网格线
grid on;
